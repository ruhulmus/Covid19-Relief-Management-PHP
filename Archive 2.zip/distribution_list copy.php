<?php
	echo "{
		  "distribution_list": [
		    {
		      "id": "1",
		      "user_id": "1",
		      "upazila_id": "401",
		      "address": "goniganj",
		      "no_of_family": "70",
		      "releife_items": "Chal,Dal,Oil,",
		      "survival_day": "3",
		      "is_needed": "1",
		      "needed_no_of_family": "40",
		      "distribute_date": "2020-04-20",
		      "created_at": "2020-04-20",
		    },
		    {
		     "id": "1",
		      "user_id": "1",
		      "upazila_id": "401",
		      "address": "goniganj",
		      "no_of_family": "70",
		      "releife_items": "Chal,Dal,Oil,",
		      "survival_day": "3",
		      "is_needed": "1",
		      "needed_no_of_family": "40",
		      "distribute_date": "2020-04-20",
		      "created_at": "2020-04-20",
   			}
   			]
		}"
 ?>